# FTC_SystemSim

A simple robot simulator for System Level tradeoff Analysis visualization with matplotlib.

## Install

from Anaconda prompt do:

```
pip install numpy
pip install matplotlib


pip install "git+git://github.com/bblais/RobotSim373" --upgrade
```
